const API_URL = "/posts";
const postForm = document.getElementById("post-form");
const postsContainer = document.getElementById("posts-container");

// Fetch and render all posts
async function loadPosts() {
  const res = await fetch(API_URL);
  const posts = await res.json();

  postsContainer.innerHTML = "";
  posts.slice().reverse().forEach((post) => {
    const postEl = document.createElement("div");
    postEl.className = "card";

    const commentsHtml = post.comments
      .map((c) => `<li>${escapeHTML(c.text)}</li>`)
      .join("");

    postEl.innerHTML = `
      <div class="post-header">
        <h3>${escapeHTML(post.title)}</h3>
        <small>#${post.id}</small>
      </div>
      <p class="post-content">${escapeHTML(post.content)}</p>
      <div class="post-actions">
        <button class="btn-like" onclick="likePost(${post.id})">❤️ ${post.likes}</button>
        <button class="btn-edit" onclick="editPost(${post.id}, '${escapeQuotes(post.title)}', '${escapeQuotes(post.content)}')">Edit</button>
        <button class="btn-delete" onclick="deletePost(${post.id})">Delete</button>
      </div>
      <div class="comments-section">
        <ul class="comment-list">${commentsHtml}</ul>
        <form class="comment-form" onsubmit="addComment(event, ${post.id})">
          <input type="text" placeholder="Write a comment..." required />
          <button type="submit">Reply</button>
        </form>
      </div>
    `;
    postsContainer.appendChild(postEl);
  });
}

// POST /posts
postForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const title = document.getElementById("post-title").value;
  const content = document.getElementById("post-content").value;

  await fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title, content })
  });

  postForm.reset();
  loadPosts();
});

// PUT /posts/:id
async function editPost(id, currentTitle, currentContent) {
  const title = prompt("Edit title:", currentTitle);
  if (title === null) return;
  const content = prompt("Edit content:", currentContent);
  if (content === null) return;

  await fetch(`${API_URL}/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title, content })
  });
  loadPosts();
}

// DELETE /posts/:id
async function deletePost(id) {
  await fetch(`${API_URL}/${id}`, { method: "DELETE" });
  loadPosts();
}

// POST /posts/:id/like
async function likePost(id) {
  await fetch(`${API_URL}/${id}/like`, { method: "POST" });
  loadPosts();
}

// POST /posts/:id/comments
async function addComment(e, id) {
  e.preventDefault();
  const input = e.target.querySelector("input");
  const text = input.value;

  await fetch(`${API_URL}/${id}/comments`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text })
  });
  loadPosts();
}

function escapeHTML(str) {
  return str.replace(/[&<>"']/g, (m) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[m]));
}

function escapeQuotes(str) {
  return str.replace(/'/g, "\'").replace(/"/g, "&quot;");
}

// Initial load
loadPosts();
