const express = require("express");
const path = require("path");
const app = express();

app.use(express.json());
// Serve frontend files from the 'public' folder
app.use(express.static(path.join(__dirname, "public")));

// In-memory storage
let posts = [
  {
    id: 1,
    title: "Hello World",
    content: "First post on Mini-Twitter!",
    likes: 2,
    comments: [{ id: 1, text: "Welcome!" }]
  }
];
let nextPostId = 2;
let nextCommentId = 2;

// 1. GET /posts - Retrieve all posts
app.get("/posts", (req, res) => {
  res.json(posts);
});

// 2. GET /posts/:id - Retrieve a single post by ID
app.get("/posts/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const post = posts.find((p) => p.id === id);

  if (!post) {
    return res.status(404).json({ error: "Post not found" });
  }
  res.json(post);
});

// 3. POST /posts - Create a new post
app.post("/posts", (req, res) => {
  const { title, content } = req.body;

  if (!title || !content) {
    return res.status(400).json({ error: "Title and content are required" });
  }

  const newPost = {
    id: nextPostId++,
    title,
    content,
    likes: 0,
    comments: []
  };

  posts.push(newPost);
  console.log(`Added new post: ${JSON.stringify(newPost)}`);
  res.status(201).json(newPost);
});

// 4. PUT /posts/:id - Update an existing post
app.put("/posts/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const post = posts.find((p) => p.id === id);

  if (!post) {
    return res.status(404).json({ error: "Post not found" });
  }

  const { title, content } = req.body;
  if (title !== undefined) post.title = title;
  if (content !== undefined) post.content = content;

  res.json(post);
});

// 5. DELETE /posts/:id - Delete a post
app.delete("/posts/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const index = posts.findIndex((p) => p.id === id);

  if (index === -1) {
    return res.status(404).json({ error: "Post not found" });
  }

  posts.splice(index, 1);
  res.status(204).end();
});

// 6. POST /posts/:id/like - Increment likes on a post
app.post("/posts/:id/like", (req, res) => {
  const id = parseInt(req.params.id);
  const post = posts.find((p) => p.id === id);

  if (!post) {
    return res.status(404).json({ error: "Post not found" });
  }

  post.likes += 1;
  res.json(post);
});

// 7. POST /posts/:id/comments - Add a comment to a post
app.post("/posts/:id/comments", (req, res) => {
  const id = parseInt(req.params.id);
  const post = posts.find((p) => p.id === id);

  if (!post) {
    return res.status(404).json({ error: "Post not found" });
  }

  const { text } = req.body;
  if (!text) {
    return res.status(400).json({ error: "Comment text is required" });
  }

  const newComment = { id: nextCommentId++, text };
  post.comments.push(newComment);
  res.status(201).json(newComment);
});

app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});
